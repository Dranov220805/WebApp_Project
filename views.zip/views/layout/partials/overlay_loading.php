<?php
?>
<div id="overlay-loading" class="loading d-none">
    <img style="width: 150px; border-radius: 50%;" src="/public/img/general/loading.svg" draggable="false" alt="">
</div>