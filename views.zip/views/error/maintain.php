<?php
?>
<!doctype html>
<html lang="en">
<head>
    <?php
        include "./views/layout/partials/header.php";
    ?>
</head>
<body style="background-color: #fcfcfc; height: 100vh">

    <div class="text-center h-100 pt-5">
        <img style="width: 100%" src="/public/img/error/maintenance_2.gif" alt="">
        <h1 style="font-weight: bold">Vui lòng quay lại sau</h1>
        <p>Trang web đang được bảo trì</p>
    </div>

</body>
</html>
