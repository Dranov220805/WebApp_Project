<?php

class ErrorMiddleWare {

//    private ErrorController $errorController;
//
//    public function __construct() {
//        $this->errorController = new ErrorController();
//    }

//    public function index() {
//        if (!isset($_SESSION['roleId'])) {
//            header('location: /log/login');
//        } else {
//            include './views/error/404.php';
//        }
//    }
}
?>