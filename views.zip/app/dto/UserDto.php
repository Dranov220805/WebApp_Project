<?php

class UserDto
{

}