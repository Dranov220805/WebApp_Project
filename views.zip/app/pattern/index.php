<?php

    include "./app/pattern/builder/index.php";
    include "./app/pattern/singleton/index.php";

?>