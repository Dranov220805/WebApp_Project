<?php
    include "./app/models/Account.php";
    include "./app/models/Image.php";
    include "./app/models/LogNote.php";
    include "./app/models/Modification.php";
    include "./app/models/Note.php";
    include "./app/models/NoteLabel.php";
    include "./app/models/NoteProtect.php";
    include "./app/models/NoteSharing.php";
    include "./app/models/Preferences.php";
    include "./app/models/User.php";
?>