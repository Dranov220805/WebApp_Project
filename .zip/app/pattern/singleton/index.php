<?php

    include "./app/pattern/singleton/CacheManager.php";

?>