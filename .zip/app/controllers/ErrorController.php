<?php

class ErrorController {

    public function index() {
        include './views/error/404.php';
    }
}

?>