<?php
include "./app/controllers/Base/BaseController.php";
include "./app/controllers/AuthController.php";
include "./app/controllers/HomeUserController.php";
include "./app/controllers/ErrorController.php";
include "./app/controllers/NoteController.php";
include "./app/controllers/RegisterController.php";
?>